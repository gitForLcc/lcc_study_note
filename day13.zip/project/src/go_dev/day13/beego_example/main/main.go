package main

import (
	_ "go_dev/day13/beego_example/router"

	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}
