package main

import(
	"fmt"
)

func test_goroute(a int) {
	fmt.Println(a)
}